#!/bin/bash

source /opt/rh/nodejs010/enable

npm install

