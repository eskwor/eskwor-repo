<html>
<head>
	<title>Test PHP passed</title>
</head>
<body>
<h1>PHP is working</h1>
<p>
<?php
	phpinfo();
?>
</p>
</body>
</html>
